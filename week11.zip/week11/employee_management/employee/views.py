import json
from django.db.models.functions import Concat
from django.db.models import Value,F,Count
from django.shortcuts import redirect, render
from django.views import View
# from httpcore import request
from company.models import *
from .models import *
from django.http import JsonResponse
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.http import HttpResponse
from django.views import View
from django.db import transaction
from .forms import EmployeeForm, ProjectDetailForm, ProjectForm
# Create your views here.
class IndexView(View):
    def get(self, request):
        # employee_fullname = Employee.objects.annotate(fullname = Concat(F('first_name'),Value(' '),F('last_name'))).order_by("-hire_date")
        employees = Employee.objects.all().order_by("-hire_date")
        for employee in employees:
            employee.position = Position.objects.get(pk=employee.position_id)
        employee_num = employees.count()
        context = {"num" : employee_num,
                   "fullname" : employees}
        return render(request, "employee.html", context)

class PositionView(View):
    def get(self, request):
        position_count = Position.objects.annotate(posi_coount = Count("employee")).order_by("id")
        context = {"position_count" : position_count}
        return render(request, "position.html", context)
    
class ProjectView(View):
    def get(self, request):
        project = Project.objects.all()
        context = {"project" : project}
        return render(request, "project.html", context)
    
    def delete(self, request,dele):
        pro_id = Project.objects.get(id=dele)
        pro_id.delete()
        return JsonResponse({'status': 'ok'})

class ProjectDetailView(View):
    def get(self, request, detail):
        project_detail = Project.objects.get(pk=detail)
        form = ProjectDetailForm(instance=project_detail)
        all_project = project_detail.staff.all()
        sdate = project_detail.start_date.strftime("%Y-%m-%d")
        ddate = project_detail.due_date.strftime("%Y-%m-%d")
        context = { "form" : form,
                   "project_detail": project_detail,
                   "sdate" : sdate,
                   "ddate" : ddate,
                   "all_project" : all_project}
        return render(request, "project_detail.html", context)
    def post(self, request, detail):
        # for updating article instance set instance=article
        project_detail = Project.objects.get(pk=detail)
        form = ProjectDetailForm(request.POST, instance=project_detail)
        all_project = project_detail.staff.all()
        sdate = project_detail.start_date.strftime("%Y-%m-%d")
        ddate = project_detail.due_date.strftime("%Y-%m-%d")
        context = { "form" : form,
                   "project_detail": project_detail,
                   "sdate" : sdate,
                   "ddate" : ddate,
                   "all_project" : all_project}
        # save if valid                                       
        if form.is_valid():                                                                      
            form.save()                                                                          
            return render(request, "project_detail.html",context)

        return render(request, "project_detail.html", context)
         
    def delete(self, request, project_id, emp_id):
        project = Project.objects.get(id=project_id)
        employee = Employee.objects.get(id=emp_id)
        project.staff.remove(employee)
        return JsonResponse({'status': 'ok'})
    
    def put(self, request, project_id, emp_id):
        project = Project.objects.get(id=project_id)
        employee = Employee.objects.get(id=emp_id)
        if employee not in project.staff.all():
            project.staff.add(employee)
        return JsonResponse({'status': 'ok'})
    
class EmployeeFormView(View):
    def get(self, request):
        form = EmployeeForm()
        return render(request, "employee_form.html", {"form": form})
    def post(self, request):
        with transaction.atomic():
            form = EmployeeForm(request.POST)
            if form.is_valid():
                    # form.save()
                first_name = form.cleaned_data["first_name"]
                last_name = form.cleaned_data["last_name"]
                gender = form.cleaned_data["gender"]
                birth_date = form.cleaned_data["birth_date"]
                hire_date = form.cleaned_data["hire_date"]
                salary = form.cleaned_data["salary"]
                position = form.cleaned_data["position"].id
                location = form.cleaned_data["location"]
                district = form.cleaned_data["district"]
                province = form.cleaned_data["province"]
                postal_code = form.cleaned_data["postal_code"]

                new_employee = Employee.objects.create(
                    first_name = first_name,
                    last_name = last_name,
                    gender = gender,
                    birth_date = birth_date,
                    hire_date = hire_date,
                    salary = salary,
                    position_id = position,
                )
                emp_address = EmployeeAddress(
                    employee = new_employee,
                    location = location,
                    district = district,
                    province = province,
                    postal_code = postal_code
                )
                emp_address.save()

                return redirect('employee')
            return render(request, "employee_form.html", {"form": form})

class ProjectFormView(View):
    def get(self, request):
        form = ProjectForm()
        return render(request, "project_form.html", {"form": form})
    def post(self, request):
        form = ProjectForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('project')
        return render(request, "project_form.html", {"form": form})



