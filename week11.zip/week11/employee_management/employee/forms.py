from datetime import date,datetime
from django import forms
from django.forms import ModelForm, SplitDateTimeField
from django.forms.widgets import Textarea, TextInput, DateInput
from django.core.exceptions import ValidationError

from company.models import *
from .models import *

# class EmployeeForm(ModelForm):
#     GENDER_CHOICES = (
#         (1, 'M'),
#         (2, 'F'),
#         (3, 'LGBT'),
#     )
#     class Meta:
#         model = Employee
#         fields = [
#             "first_name",
#             "last_name",
#             "gender",
#             "birth_date",
#             "hire_date",
#             "salary",
#             "position"
#         ]
#         widgets = {
#             "birth_date" : DateInput(attrs={"type": "date"}),
#             "hire_date" : DateInput(attrs={"type": "date"})
#             }
    
#     def clean(self):
#         cleaned_data = super().clean()
#         hire_date = cleaned_data.get("hire_date")
#         hire_now = datetime.now().date()
#         if hire_date > hire_now:
#             raise ValidationError(
#                     "hire_date ว่าจะต้องไม่เป็นวันในอนาคต"
#             )
#         return cleaned_data
class EmployeeForm(forms.ModelForm):
    position = forms.ModelChoiceField(queryset=Position.objects.all())
    location = forms.CharField(widget=forms.TextInput(attrs={"cols": 30, "rows": 3}))
    district = forms.CharField(max_length=100)
    province = forms.CharField(max_length=100)
    postal_code = forms.CharField(max_length=15)

    class Meta:
        model = Employee
        fields = [
            "first_name", 
            "last_name", 
            "gender", 
            "birth_date", 
            "hire_date", 
            "salary", 
            "position",
            "location",
            "district",
            "province",
            "postal_code"
        ]
        widgets = {
            'birth_date': forms.widgets.DateInput(attrs={'type': 'date'}),
            'hire_date': forms.widgets.DateInput(attrs={'type': 'date'})
        }
    
class ProjectForm(ModelForm):
    class Meta:
        model = Project
        fields = [
            "name",
            "manager",
            "start_date",
            "due_date",
            "description",
        ]
        widgets = {
            "start_date" : DateInput(attrs={"type": "date"}),
            "due_date" : DateInput(attrs={"type": "date"})
            }
    
    def clean(self):
        cleaned_data = super().clean()
        start_date = cleaned_data.get("start_date")
        due_date = cleaned_data.get("due_date")
        if start_date > due_date:
            raise ValidationError(
                    "due_date cannot be before start_date"
            )
        return cleaned_data

class ProjectDetailForm(ModelForm):
    class Meta:
        model = Project
        fields = [
            "name",
            "manager",
            "start_date",
            "due_date",
            "description",
            "staff"
        ]
        widgets = {
            "start_date" : DateInput(attrs={"type": "date"}),
            "due_date" : DateInput(attrs={"type": "date"})
            }
    
    def clean(self):
        cleaned_data = super().clean()
        start_date = cleaned_data.get("start_date")
        due_date = cleaned_data.get("due_date")
        manager = cleaned_data.get("manager")
        if start_date > due_date:
            raise ValidationError(
                    "due_date cannot be before start_date"
            )
        return cleaned_data